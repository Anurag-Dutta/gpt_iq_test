#include <iostream>
#include <cstring>

const int MOD = 1e9 + 7;
const int N = 7;
int dp[N][N];

int main() {
    std::string description;
    std::cin >> description;

    memset(dp, 0, sizeof(dp));
    dp[0][0] = 1;

    for (char c : description) {
        int new_dp[N][N] = {};
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (c == '?' || c == 'D' && i > 0 || c == 'U' && i < N - 1 || c == 'L' && j > 0 || c == 'R' && j < N - 1) {
                    if (c == '?' || c == 'D') {
                        new_dp[i][j] += dp[i - 1][j];
                        new_dp[i][j] %= MOD;
                    }
                    if (c == '?' || c == 'U') {
                        new_dp[i][j] += dp[i + 1][j];
                        new_dp[i][j] %= MOD;
                    }
                    if (c == '?' || c == 'L') {
                        new_dp[i][j] += dp[i][j - 1];
                        new_dp[i][j] %= MOD;
                    }
                    if (c == '?' || c == 'R') {
                        new_dp[i][j] += dp[i][j + 1];
                        new_dp[i][j] %= MOD;
                    }
                }
            }
        }
        memcpy(dp, new_dp, sizeof(dp));
    }

    std::cout << dp[N - 1][N - 1] << std::endl;

    return 0;
}
