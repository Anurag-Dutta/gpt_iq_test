#include <iostream>

// Define modulo constant
const int MOD = 1000000007;

// Function to calculate power a^b modulo MOD
int power(int a, int b) {
    if (b == 0) {
        return 1;
    }
    long long result = power(a, b / 2);
    result = (result * result) % MOD;
    if (b % 2 == 1) {
        result = (result * a) % MOD;
    }
    return result;
}

int main() {
    int n;
    std::cin >> n;

    // Calculate 2^n modulo MOD
    int result = power(2, n);

    // Print the result
    std::cout << result << std::endl;

    return 0;
}
