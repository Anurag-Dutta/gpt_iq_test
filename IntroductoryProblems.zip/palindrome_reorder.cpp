#include <iostream>
#include <string>
#include <unordered_map>

int main() {
    std::string s;
    std::cin >> s;

    std::unordered_map<char, int> freq;

    // Count the frequency of each character
    for (char c : s) {
        freq[c]++;
    }

    std::string palindrome;

    char oddChar = '\0'; // Initialize to null character
    for (auto it : freq) {
        if (it.second % 2 == 1) {
            // If a character appears an odd number of times, keep track of it
            if (oddChar != '\0') {
                // If we already have an odd character, the palindrome is not possible
                std::cout << "NO SOLUTION\n";
                return 0;
            }
            oddChar = it.first;
        } else {
            // Append half of the characters to the palindrome
            palindrome.append(it.second / 2, it.first);
        }
    }

    // If there is an odd character, append it once to the middle
    if (oddChar != '\0') {
        palindrome.push_back(oddChar);
    }

    // Append the reversed half of the characters to complete the palindrome
    for (int i = palindrome.size() - 1; i >= 0; --i) {
        palindrome.push_back(palindrome[i]);
    }

    std::cout << palindrome << std::endl;

    return 0;
}
