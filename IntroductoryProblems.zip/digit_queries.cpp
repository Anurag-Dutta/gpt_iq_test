#include <iostream>
#include <cmath>

int main() {
    int q;
    std::cin >> q;

    while (q--) {
        long long k;
        std::cin >> k;

        // Find the length of the block containing k
        long long block_length = 9;
        long long block_start = 1;
        int digits = 1;
        while (k > block_length * digits) {
            k -= block_length * digits;
            block_start += block_length;
            block_length *= 10;
            ++digits;
        }

        // Find the number at position k within the block
        long long number = block_start + (k - 1) / digits;

        // Find the digit at position k within the number
        int digit_index = (k - 1) % digits;
        int digit = 0;
        while (digit_index < digits) {
            digit = number % 10;
            number /= 10;
            ++digit_index;
        }

        std::cout << digit << "\n";
    }

    return 0;
}
