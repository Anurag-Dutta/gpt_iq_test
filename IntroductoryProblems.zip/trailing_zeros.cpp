#include <iostream>

int countTrailingZeros(int n) {
    int zeros = 0;
    // Divide n by powers of 5 and count the number of multiples of 5
    while (n >= 5) {
        zeros += n / 5;
        n /= 5;
    }
    return zeros;
}

int main() {
    int n;
    std::cin >> n;

    // Calculate the number of trailing zeros in n!
    int trailingZeros = countTrailingZeros(n);

    // Print the result
    std::cout << trailingZeros << std::endl;

    return 0;
}
