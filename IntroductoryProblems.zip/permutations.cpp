#include <iostream>
#include <vector>

void beautifulPermutation(int n) {
    if (n == 1) {
        std::cout << "1\n";
        return;
    }

    std::vector<int> permutation;

    // Add all even numbers up to n
    for (int i = 2; i <= n; i += 2) {
        permutation.push_back(i);
    }

    // Add all odd numbers up to n
    for (int i = 1; i <= n; i += 2) {
        permutation.push_back(i);
    }

    // If n is odd and the last element is adjacent to the second-last element, no solution exists
    if (n % 2 == 1 && permutation[n - 1] - permutation[n - 2] == 1) {
        std::cout << "NO SOLUTION\n";
        return;
    }

    // Print the beautiful permutation
    for (int num : permutation) {
        std::cout << num << " ";
    }
    std::cout << "\n";
}

int main() {
    int n;
    std::cin >> n;
    beautifulPermutation(n);
    return 0;
}
