#include <iostream>
#include <vector>

const int n = 8; // Size of the chessboard

int countWays(int row, std::vector<std::vector<bool>>& board, std::vector<bool>& col,
              std::vector<bool>& diag1, std::vector<bool>& diag2) {
    if (row == n) {
        return 1; // All queens are placed successfully
    }

    int ways = 0;

    for (int i = 0; i < n; ++i) {
        if (!col[i] && !diag1[row + i] && !diag2[row - i + n - 1] && board[row][i] == '.') {
            col[i] = diag1[row + i] = diag2[row - i + n - 1] = true;
            ways += countWays(row + 1, board, col, diag1, diag2);
            col[i] = diag1[row + i] = diag2[row - i + n - 1] = false;
        }
    }

    return ways;
}

int main() {
    std::vector<std::vector<bool>> board(n, std::vector<bool>(n, false)); // Chessboard
    std::vector<bool> col(n, false); // Check if column is attacked
    std::vector<bool> diag1(2 * n - 1, false); // Check if diagonal 1 is attacked
    std::vector<bool> diag2(2 * n - 1, false); // Check if diagonal 2 is attacked

    // Read the input
    for (int i = 0; i < n; ++i) {
        std::string row;
        std::cin >> row;
        for (int j = 0; j < n; ++j) {
            board[i][j] = row[j];
        }
    }

    // Count the number of ways to place queens
    int ways = countWays(0, board, col, diag1, diag2);

    std::cout << ways << std::endl;

    return 0;
}
