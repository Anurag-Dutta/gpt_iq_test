#include <iostream>
#include <string>

int longestRepetition(const std::string& sequence) {
    int maxLength = 0;
    int currentLength = 1;

    // Iterate through the sequence starting from the second character
    for (int i = 1; i < sequence.length(); ++i) {
        // If the current character is the same as the previous one, increase the current length
        if (sequence[i] == sequence[i - 1]) {
            currentLength++;
        } else {
            // If the current repetition is longer than the previous maximum, update the maximum
            maxLength = std::max(maxLength, currentLength);
            // Reset the current length for the new character
            currentLength = 1;
        }
    }

    // Check if the last repetition is longer than the previous maximum
    maxLength = std::max(maxLength, currentLength);

    return maxLength;
}

int main() {
    std::string sequence;
    std::cin >> sequence;

    // Calculate and print the length of the longest repetition
    std::cout << longestRepetition(sequence) << std::endl;

    return 0;
}
