#include <iostream>

bool canEmptyPiles(int a, int b) {
    // Check if the total number of coins is divisible by 3
    if ((a + b) % 3 == 0) {
        // Check if both piles can be emptied
        return (2 * std::min(a, b) >= std::max(a, b));
    }
    return false;
}

int main() {
    int t;
    std::cin >> t;

    while (t--) {
        int a, b;
        std::cin >> a >> b;

        // Check if it's possible to empty both piles
        if (canEmptyPiles(a, b)) {
            std::cout << "YES\n";
        } else {
            std::cout << "NO\n";
        }
    }

    return 0;
}
