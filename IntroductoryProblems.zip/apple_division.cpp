#include <iostream>
#include <vector>
#include <cmath>
#include <climits>

void divideApples(const std::vector<int>& apples, int index, int sum1, int sum2, int& minDiff) {
    // Base case: All apples have been considered
    if (index == apples.size()) {
        // Update the minimum difference
        minDiff = std::min(minDiff, std::abs(sum1 - sum2));
        return;
    }

    // Include the current apple in the first group
    divideApples(apples, index + 1, sum1 + apples[index], sum2, minDiff);

    // Include the current apple in the second group
    divideApples(apples, index + 1, sum1, sum2 + apples[index], minDiff);
}

int main() {
    int n;
    std::cin >> n;

    std::vector<int> apples(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> apples[i];
    }

    // Initialize the minimum difference to maximum possible value
    int minDiff = INT_MAX;

    // Start dividing the apples into two groups recursively
    divideApples(apples, 0, 0, 0, minDiff);

    // Print the minimum difference
    std::cout << minDiff << std::endl;

    return 0;
}
