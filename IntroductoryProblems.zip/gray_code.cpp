#include <iostream>
#include <vector>
#include <string>

// Function to generate Gray code for n bits
std::vector<std::string> generateGrayCode(int n) {
    // Base case: for n = 1
    if (n == 1) {
        return {"0", "1"};
    }
    
    // Recursively generate Gray code for n-1 bits
    std::vector<std::string> prevGrayCode = generateGrayCode(n - 1);
    
    // Reflect and add leading '1' to the previously generated Gray code in reverse order
    std::vector<std::string> grayCode;
    for (int i = 0; i < prevGrayCode.size(); ++i) {
        grayCode.push_back("0" + prevGrayCode[i]);
    }
    for (int i = prevGrayCode.size() - 1; i >= 0; --i) {
        grayCode.push_back("1" + prevGrayCode[i]);
    }
    
    return grayCode;
}

int main() {
    int n;
    std::cin >> n;

    // Generate Gray code for n bits
    std::vector<std::string> grayCode = generateGrayCode(n);

    // Print the generated Gray code
    for (const std::string& code : grayCode) {
        std::cout << code << "\n";
    }

    return 0;
}
