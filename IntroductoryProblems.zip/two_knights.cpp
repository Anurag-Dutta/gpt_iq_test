#include <iostream>

long long countKnightPlacements(int n) {
    long long result = 0;
    for (int k = 1; k <= n; ++k) {
        long long squares = 1LL * k * k;
        result = squares * (squares - 1) / 2 - 4 * (k - 1) * (k - 2);
        std::cout << result << "\n";
    }
}

int main() {
    int n;
    std::cin >> n;

    countKnightPlacements(n);

    return 0;
}
