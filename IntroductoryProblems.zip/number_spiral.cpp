#include <iostream>

long long numberInSpiral(int y, int x) {
    long long maxCoord = std::max(y, x);
    long long base = maxCoord * maxCoord - maxCoord + 1;
    
    if (maxCoord % 2 == 0) {
        if (y == maxCoord)
            return base + (x - maxCoord);
        else
            return base - (y - maxCoord);
    } else {
        if (x == maxCoord)
            return base + (y - maxCoord);
        else
            return base - (x - maxCoord);
    }
}

int main() {
    int t;
    std::cin >> t;

    while (t--) {
        int y, x;
        std::cin >> y >> x;
        std::cout << numberInSpiral(y, x) << std::endl;
    }

    return 0;
}
