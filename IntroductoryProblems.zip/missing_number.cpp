#include <iostream>

int main() {
    int n;
    std::cin >> n;

    // Calculate the sum of all numbers from 1 to n
    long long total_sum = (1LL * n * (n + 1)) / 2;

    // Subtract the sum of given numbers
    long long given_sum = 0;
    for (int i = 0; i < n - 1; ++i) {
        int num;
        std::cin >> num;
        given_sum += num;
    }

    // Print the missing number
    std::cout << total_sum - given_sum << std::endl;

    return 0;
}
