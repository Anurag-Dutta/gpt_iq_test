#include <iostream>
#include <cmath>
#include <vector>

void towerOfHanoi(int n, int source, int target, int auxiliary, std::vector<std::pair<int, int>>& moves) {
    if (n == 1) {
        // If there is only one disk, move it directly from the source to the target
        moves.push_back({source, target});
    } else {
        // Move n-1 disks from the source to the auxiliary stack using the target stack
        towerOfHanoi(n - 1, source, auxiliary, target, moves);
        // Move the largest disk from the source to the target stack
        moves.push_back({source, target});
        // Move n-1 disks from the auxiliary stack to the target stack using the source stack
        towerOfHanoi(n - 1, auxiliary, target, source, moves);
    }
}

int main() {
    int n;
    std::cin >> n;

    std::vector<std::pair<int, int>> moves;

    // Call the Tower of Hanoi function
    towerOfHanoi(n, 1, 3, 2, moves);

    // Print the number of moves
    std::cout << moves.size() << "\n";

    // Print the moves
    for (const auto& move : moves) {
        std::cout << move.first << " " << move.second << "\n";
    }

    return 0;
}
