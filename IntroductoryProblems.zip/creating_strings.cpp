#include <iostream>
#include <string>
#include <algorithm>
#include <vector>

void generatePermutations(std::string& s, int index, std::vector<std::string>& result) {
    if (index == s.length() - 1) {
        result.push_back(s);
        return;
    }
    
    for (int i = index; i < s.length(); ++i) {
        std::swap(s[index], s[i]);
        generatePermutations(s, index + 1, result);
        std::swap(s[index], s[i]);
    }
}

int main() {
    std::string s;
    std::cin >> s;

    std::vector<std::string> permutations;
    
    // Generate all permutations of the string
    generatePermutations(s, 0, permutations);
    
    // Sort the permutations to get strings in alphabetical order
    std::sort(permutations.begin(), permutations.end());
    
    // Print the number of strings
    std::cout << permutations.size() << "\n";
    
    // Print the strings
    for (const std::string& str : permutations) {
        std::cout << str << "\n";
    }

    return 0;
}
