#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <cmath>
#include <limits>

using namespace std;

struct Point {
    int x, y;
};

bool compareX(const Point& a, const Point& b) {
    return a.x < b.x;
}

bool compareY(const Point& a, const Point& b) {
    return a.y < b.y;
}

int squaredDistance(const Point& a, const Point& b) {
    int dx = a.x - b.x;
    int dy = a.y - b.y;
    return dx * dx + dy * dy;
}

int main() {
    int n;
    cin >> n;

    vector<Point> points(n);
    for (int i = 0; i < n; ++i) {
        cin >> points[i].x >> points[i].y;
    }

    sort(points.begin(), points.end(), compareX);

    int min_dist_sq = numeric_limits<int>::max();
    set<Point, decltype(compareY)*> active_points(compareY);

    for (int i = 0, j = 0; i < n; ++i) {
        while (j < i && points[i].x - points[j].x > min_dist_sq) {
            active_points.erase(points[j++]);
        }

        for (auto it = active_points.lower_bound({points[i].x, points[i].y - sqrt(min_dist_sq)}); it != active_points.end() && it->y <= points[i].y + sqrt(min_dist_sq); ++it) {
            min_dist_sq = min(min_dist_sq, squaredDistance(points[i], *it));
        }

        active_points.insert(points[i]);
    }

    cout << min_dist_sq << endl;

    return 0;
}
