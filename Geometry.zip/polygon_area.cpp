#include <iostream>
#include <vector>
using namespace std;

struct Point {
    int x, y;
};

// Function to calculate the area of a polygon using the Shoelace formula
int calculateArea(const vector<Point>& polygon) {
    int area = 0;
    int n = polygon.size();

    // Apply the Shoelace formula
    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        area += (polygon[i].x * polygon[j].y - polygon[j].x * polygon[i].y);
    }

    // Ensure non-negative area and return the result
    return abs(area);
}

int main() {
    int n;
    cin >> n;

    vector<Point> polygon(n);
    for (int i = 0; i < n; ++i) {
        cin >> polygon[i].x >> polygon[i].y;
    }

    int area = calculateArea(polygon);
    cout << 2 * area << endl;

    return 0;
}
