#include <iostream>
using namespace std;

struct Point {
    int x, y;
};

int crossProduct(const Point& p1, const Point& p2, const Point& p3) {
    return (p2.x - p1.x) * (p3.y - p1.y) - (p3.x - p1.x) * (p2.y - p1.y);
}

string determinePosition(const Point& p1, const Point& p2, const Point& p3) {
    int cross = crossProduct(p1, p2, p3);
    if (cross > 0) {
        return "LEFT";
    } else if (cross < 0) {
        return "RIGHT";
    } else {
        return "TOUCH";
    }
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        Point p1, p2, p3;
        cin >> p1.x >> p1.y >> p2.x >> p2.y >> p3.x >> p3.y;
        cout << determinePosition(p1, p2, p3) << endl;
    }

    return 0;
}
