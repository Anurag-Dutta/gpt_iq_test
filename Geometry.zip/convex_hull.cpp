#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <cmath>

using namespace std;

struct Point {
    int x, y;
};

// Function to compute the cross product of two vectors (p1p2 and p2p3)
// Returns a positive value if the points are in counterclockwise order,
// a negative value if they are in clockwise order, and zero if they are collinear.
int crossProduct(const Point& p1, const Point& p2, const Point& p3) {
    return (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
}

// Function to compute the squared Euclidean distance between two points
int squaredDistance(const Point& p1, const Point& p2) {
    int dx = p1.x - p2.x;
    int dy = p1.y - p2.y;
    return dx * dx + dy * dy;
}

// Function to compare points by polar angle with respect to the lowest point
bool compareByPolarAngle(const Point& lowestPoint, const Point& p1, const Point& p2) {
    int cross = crossProduct(lowestPoint, p1, p2);
    if (cross == 0) {
        // If collinear, put the point closer to lowestPoint first
        return squaredDistance(lowestPoint, p1) < squaredDistance(lowestPoint, p2);
    }
    return cross > 0;
}

int main() {
    int n;
    cin >> n;

    vector<Point> points(n);
    for (int i = 0; i < n; ++i) {
        cin >> points[i].x >> points[i].y;
    }

    // Find the point with the lowest y-coordinate (and the leftmost point in case of a tie)
    int lowestIndex = 0;
    for (int i = 1; i < n; ++i) {
        if (points[i].y < points[lowestIndex].y || (points[i].y == points[lowestIndex].y && points[i].x < points[lowestIndex].x)) {
            lowestIndex = i;
        }
    }

    // Swap the lowest point with the first point
    swap(points[0], points[lowestIndex]);

    // Sort the remaining points by their polar angle with respect to the lowest point
    sort(points.begin() + 1, points.end(), [&](const Point& p1, const Point& p2) {
        return compareByPolarAngle(points[0], p1, p2);
    });

    // Initialize the convex hull stack with the first two points
    stack<Point> convexHull;
    convexHull.push(points[0]);
    convexHull.push(points[1]);

    // Traverse the sorted points and add them to the convex hull
    for (int i = 2; i < n; ++i) {
        while (convexHull.size() >= 2) {
            Point top = convexHull.top();
            convexHull.pop();
            Point secondTop = convexHull.top();
            if (crossProduct(secondTop, top, points[i]) > 0) {
                convexHull.push(top);
                break;
            }
        }
        convexHull.push(points[i]);
    }

    // Print the convex hull
    cout << convexHull.size() << endl;
    while (!convexHull.empty()) {
        Point p = convexHull.top();
        cout << p.x << " " << p.y << endl;
        convexHull.pop();
    }

    return 0;
}
