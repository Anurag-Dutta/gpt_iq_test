#include <iostream>
#include <vector>
using namespace std;

struct Point {
    int x, y;
};

// Function to check if a point is on the left side of a line segment
bool isLeft(const Point& p1, const Point& p2, const Point& p3) {
    return (p2.x - p1.x) * (p3.y - p1.y) - (p3.x - p1.x) * (p2.y - p1.y) > 0;
}

// Function to check if a point is inside, outside, or on the boundary of a polygon
string pointLocation(const vector<Point>& polygon, const Point& p) {
    int n = polygon.size();
    int count = 0;

    // Cast a ray from the given point and count the number of intersections with the polygon edges
    for (int i = 0, j = n - 1; i < n; j = i++) {
        if ((polygon[i].y > p.y) != (polygon[j].y > p.y) &&
            p.x < (polygon[j].x - polygon[i].x) * (p.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x) {
            count += isLeft(polygon[i], polygon[j], p) ? 1 : -1;
        }
    }

    // Determine the point location based on the number of intersections
    if (count == 0) return "OUTSIDE";
    return (count % 2 == 1) ? "INSIDE" : "BOUNDARY";
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<Point> polygon(n);
    for (int i = 0; i < n; ++i) {
        cin >> polygon[i].x >> polygon[i].y;
    }

    for (int i = 0; i < m; ++i) {
        Point p;
        cin >> p.x >> p.y;
        cout << pointLocation(polygon, p) << endl;
    }

    return 0;
}
