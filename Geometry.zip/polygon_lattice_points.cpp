#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

// Structure to represent a point
struct Point {
    int x, y;
};

// Function to calculate the area of a polygon
double polygonArea(const vector<Point>& polygon) {
    int n = polygon.size();
    double area = 0;

    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        area += (polygon[i].x * polygon[j].y - polygon[j].x * polygon[i].y);
    }

    return abs(area) / 2.0;
}

// Function to calculate the number of lattice points inside and on the boundary of a polygon
pair<int, int> latticePoints(const vector<Point>& polygon) {
    int n = polygon.size();
    double area = polygonArea(polygon);
    int boundary = 0;

    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        boundary += abs(__gcd(polygon[i].x - polygon[j].x, polygon[i].y - polygon[j].y));
    }

    return { static_cast<int>(area), boundary };
}

int main() {
    int n;
    cin >> n;

    vector<Point> polygon(n);
    for (int i = 0; i < n; ++i) {
        cin >> polygon[i].x >> polygon[i].y;
    }

    pair<int, int> result = latticePoints(polygon);
    cout << result.first << " " << result.second << endl;

    return 0;
}
