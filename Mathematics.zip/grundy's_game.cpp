#include <iostream>
#include <vector>
using namespace std;

int calculateGrundyNumber(int n) {
    if (n == 1) {
        return 0; // Base case: if there's only one coin, the first player wins
    }

    // Calculate the Grundy number recursively
    int grundy = 0;
    for (int i = 2; i <= n; ++i) {
        if (n % i == 0 && (n / i) % 2 == 1) {
            grundy = calculateGrundyNumber(n / i);
            break;
        }
    }

    return grundy;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        int grundy = calculateGrundyNumber(n);
        if (grundy == 0) {
            cout << "second" << endl;
        } else {
            cout << "first" << endl;
        }
    }

    return 0;
}
