#include <iostream>
#include <vector>
using namespace std;

const long long INF = 1e18; // Represents infinity

int main() {
    int n, m, k;
    cin >> n >> m >> k;

    // Initialize adjacency matrix with INF
    vector<vector<long long>> adj(n + 1, vector<long long>(n + 1, INF));

    // Read edges and update adjacency matrix
    for (int i = 0; i < m; ++i) {
        int a, b, c;
        cin >> a >> b >> c;
        adj[a][b] = min(adj[a][b], (long long)c);
    }

    // Initialize dp matrix with 0s and weights of edges
    vector<vector<long long>> dp(n + 1, vector<long long>(n + 1, INF));
    for (int i = 1; i <= n; ++i) {
        dp[i][1] = adj[1][i];
    }
    dp[1][0] = 0;

    // Matrix exponentiation to find shortest path with exactly k edges
    for (int i = 2; i <= k; ++i) {
        vector<vector<long long>> temp(n + 1, vector<long long>(n + 1, INF));
        for (int a = 1; a <= n; ++a) {
            for (int b = 1; b <= n; ++b) {
                for (int c = 1; c <= n; ++c) {
                    temp[b][c] = min(temp[b][c], dp[b][a] + adj[a][c]);
                }
            }
        }
        dp = temp;
    }

    // Check if there is a path from node 1 to node n with exactly k edges
    if (dp[n][n] == INF) {
        cout << -1 << endl;
    } else {
        cout << dp[n][n] << endl;
    }

    return 0;
}
