#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

long long count_coprime_pairs(vector<int>& arr) {
    int n = arr.size();
    long long coprime_pairs = 0;
    vector<long long> frequency(1000001, 0); // Frequency of each number in the range

    // Count the frequency of each number in the range
    for (int i = 0; i < n; ++i) {
        frequency[arr[i]]++;
    }

    // Iterate over all pairs
    for (int i = 1; i <= 1000000; ++i) {
        long long pairs_with_i = 0;
        // For each pair (i, j) such that j > i and i * j <= 1000000
        for (int j = i; j <= 1000000; j += i) {
            pairs_with_i += frequency[j]; // Count the frequency of j
        }
        coprime_pairs += pairs_with_i * (pairs_with_i - 1) / 2; // Add pairs of elements with gcd equal to i
    }

    return coprime_pairs;
}

int main() {
    int n;
    cin >> n;

    vector<int> arr(n);
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }

    cout << count_coprime_pairs(arr) << endl;

    return 0;
}
