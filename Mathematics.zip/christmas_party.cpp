#include <iostream>
using namespace std;

const int MOD = 1e9 + 7;
const int MAXN = 1000001;

long long factorial[MAXN];
long long inverse_factorial[MAXN];

long long power(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) {
            result = (result * base) % MOD;
        }
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

void precompute_factorials() {
    factorial[0] = inverse_factorial[0] = 1;
    for (int i = 1; i < MAXN; ++i) {
        factorial[i] = (factorial[i - 1] * i) % MOD;
        inverse_factorial[i] = power(factorial[i], MOD - 2);
    }
}

long long derangements(int n) {
    long long result = 0;
    long long sign = 1;
    for (int i = 0; i <= n; ++i) {
        result = (result + sign * (factorial[n] * inverse_factorial[i]) % MOD) % MOD;
        sign *= -1;
    }
    return result;
}

int main() {
    precompute_factorials();

    int n;
    cin >> n;

    cout << derangements(n) << endl;

    return 0;
}
