#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;

int main() {
    int n, m, k;
    cin >> n >> m >> k;

    vector<vector<int>> dp(n + 1, vector<int>(k + 1, 0));
    dp[1][0] = 1;

    vector<vector<int>> edges(m, vector<int>(2));
    for (int i = 0; i < m; ++i) {
        cin >> edges[i][0] >> edges[i][1];
    }

    for (int j = 1; j <= k; ++j) {
        for (int i = 1; i <= n; ++i) {
            for (auto edge : edges) {
                int a = edge[0], b = edge[1];
                if (i == b) {
                    dp[b][j] = (dp[b][j] + dp[a][j - 1]) % MOD;
                }
            }
        }
    }

    cout << dp[n][k] << endl;

    return 0;
}
