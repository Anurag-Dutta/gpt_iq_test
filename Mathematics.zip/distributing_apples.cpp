#include <iostream>
using namespace std;

const int MOD = 1e9 + 7;

long long power(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) {
            result = (result * base) % MOD;
        }
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

int main() {
    int n, m;
    cin >> n >> m;

    // Calculate (n + m - 1) choose (m) modulo MOD
    long long numerator = 1, denominator = 1;
    for (int i = 0; i < m; ++i) {
        numerator = (numerator * (n + m - 1 - i)) % MOD;
        denominator = (denominator * (i + 1)) % MOD;
    }
    long long result = (numerator * power(denominator, MOD - 2)) % MOD;

    cout << result << endl;

    return 0;
}
