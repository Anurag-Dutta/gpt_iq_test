#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
using namespace std;

int main() {
    int n, a, b;
    cin >> n >> a >> b;

    vector<vector<double>> dp(n + 1, vector<double>(6 * n + 1, 0));
    dp[0][0] = 1;

    for (int i = 1; i <= n; ++i) {
        for (int j = i; j <= 6 * i; ++j) {
            for (int k = 1; k <= 6 && j - k >= 0; ++k) {
                dp[i][j] += dp[i - 1][j - k];
            }
        }
    }

    double favorable_outcomes = 0;
    for (int i = a; i <= b; ++i) {
        favorable_outcomes += dp[n][i];
    }

    double total_outcomes = pow(6.0, n); // Convert one operand to double
    double probability = favorable_outcomes / total_outcomes;

    cout << fixed << setprecision(6) << probability << endl;

    return 0;
}
