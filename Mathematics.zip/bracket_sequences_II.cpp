#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;
const int MAXN = 1000001;

int dp[MAXN];

int main() {
    int n;
    cin >> n;

    string prefix;
    cin >> prefix;

    int k = prefix.size();

    dp[0] = 1;

    int open = 0;
    for (int i = 0; i < k; ++i) {
        if (prefix[i] == '(') {
            open++;
        } else {
            if (open > 0) {
                dp[i + 1] = dp[i - 1];
            }
            open--;
        }
    }

    for (int i = k; i <= n; ++i) {
        dp[i] = (dp[i - 1] + dp[i - 2]) % MOD;
    }

    cout << dp[n] << endl;

    return 0;
}
