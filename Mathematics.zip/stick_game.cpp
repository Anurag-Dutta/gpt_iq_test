#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n, k;
    cin >> n >> k;

    vector<int> moves(k);
    for (int i = 0; i < k; ++i) {
        cin >> moves[i];
    }

    vector<char> dp(n + 1, 'L');
    dp[1] = 'W'; // Base case

    for (int i = 2; i <= n; ++i) {
        for (int move : moves) {
            if (i - move >= 0 && dp[i - move] == 'L') {
                dp[i] = 'W';
                break;
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        cout << dp[i];
    }
    cout << endl;

    return 0;
}
