#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;

// Define a 2x2 matrix structure
struct Matrix {
    long long a, b, c, d;
};

// Function to multiply two matrices
Matrix multiply(Matrix x, Matrix y) {
    Matrix result;
    result.a = (x.a * y.a + x.b * y.c) % MOD;
    result.b = (x.a * y.b + x.b * y.d) % MOD;
    result.c = (x.c * y.a + x.d * y.c) % MOD;
    result.d = (x.c * y.b + x.d * y.d) % MOD;
    return result;
}

// Function to calculate matrix exponentiation
Matrix power(Matrix base, long long exp) {
    if (exp == 0) {
        return {1, 0, 0, 1}; // Identity matrix
    }
    Matrix result = power(base, exp / 2);
    result = multiply(result, result);
    if (exp % 2 == 1) {
        result = multiply(result, base);
    }
    return result;
}

// Function to calculate the nth Fibonacci number modulo MOD
long long fibonacci(long long n) {
    if (n == 0) {
        return 0;
    }
    Matrix base = {1, 1, 1, 0};
    Matrix result = power(base, n - 1);
    return result.a;
}

int main() {
    long long n;
    cin >> n;

    cout << fibonacci(n) << endl;

    return 0;
}
