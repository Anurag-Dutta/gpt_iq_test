#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;

long long sum_of_divisors(long long n) {
    long long sum = 0;
    for (long long i = 1; i <= n; ++i) {
        sum = (sum + (n / i) * i) % MOD;
    }
    return sum;
}

int main() {
    long long n;
    cin >> n;

    long long result = 0;
    for (long long i = 1; i <= n; ++i) {
        result = (result + sum_of_divisors(i)) % MOD;
    }

    cout << result << endl;

    return 0;
}
