#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

long long count_divisible_numbers(long long n, vector<int>& primes) {
    long long result = 0;
    int k = primes.size();
    for (int mask = 1; mask < (1 << k); ++mask) {
        long long product = 1, sign = -1;
        for (int i = 0; i < k; ++i) {
            if (mask & (1 << i)) {
                product *= primes[i];
                sign *= -1;
            }
        }
        result += sign * (n / product);
    }
    return result;
}

int main() {
    long long n;
    int k;
    cin >> n >> k;

    vector<int> primes(k);
    for (int i = 0; i < k; ++i) {
        cin >> primes[i];
    }

    cout << count_divisible_numbers(n, primes) << endl;

    return 0;
}
