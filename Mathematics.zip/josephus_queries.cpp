#include <iostream>
using namespace std;

int main() {
    int q;
    cin >> q;

    while (q--) {
        int n, k;
        cin >> n >> k;

        // Calculate the position of the kth child that will be removed
        int position = (k - 1 + (k - 1) / (n - 1)) % n + 1;

        cout << position << endl;
    }

    return 0;
}
