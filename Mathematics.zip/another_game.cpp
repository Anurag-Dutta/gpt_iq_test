#include <iostream>
#include <vector>
using namespace std;

int calculateNimSum(const vector<int>& heaps) {
    int nimSum = 0;
    for (int heap : heaps) {
        nimSum ^= heap;
    }
    return nimSum;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        vector<int> heaps(n);
        for (int i = 0; i < n; ++i) {
            cin >> heaps[i];
        }

        int nimSum = calculateNimSum(heaps);
        if (nimSum == 0) {
            cout << "second" << endl;
        } else {
            cout << "first" << endl;
        }
    }

    return 0;
}
