#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MOD = 1e9 + 7;

long long factorial(int n) {
    long long result = 1;
    for (int i = 2; i <= n; ++i) {
        result = (result * i) % MOD;
    }
    return result;
}

long long power(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) {
            result = (result * base) % MOD;
        }
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

int main() {
    string s;
    cin >> s;

    vector<int> frequency(26, 0);

    // Count frequency of each character
    for (char ch : s) {
        frequency[ch - 'a']++;
    }

    // Calculate the number of different strings using permutations with repetitions
    long long result = factorial(s.size());
    for (int i = 0; i < 26; ++i) {
        result = (result * power(factorial(frequency[i]), MOD - 2)) % MOD;
    }

    cout << result << endl;

    return 0;
}
