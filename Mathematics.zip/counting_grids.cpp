#include <iostream>
using namespace std;

const int MOD = 1e9 + 7;

// Function to calculate power modulo MOD
long long power(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) {
            result = (result * base) % MOD;
        }
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

int main() {
    int n;
    cin >> n;

    // Calculate 2^n^2 modulo MOD
    long long total_grids = power(2, 1LL * n * n);

    // Calculate 2^(n^2/2) modulo MOD
    long long same_grids = power(2, (n * n) / 2);

    // Calculate the number of different grids modulo 10^9+7
    long long result = (total_grids - same_grids + MOD) % MOD;

    cout << result << endl;

    return 0;
}
