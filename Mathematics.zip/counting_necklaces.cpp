#include <iostream>
#include <algorithm> // Include algorithm header for __gcd
using namespace std;

const int MOD = 1e9 + 7;

// Function to calculate power modulo MOD
long long power(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) {
            result = (result * base) % MOD;
        }
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

int main() {
    int n, m;
    cin >> n >> m;

    // Calculate the number of total necklaces without any restrictions
    long long total_necklaces = power(m, n);

    // Calculate the number of fixed points under each rotation
    long long fixed_points_sum = 0;
    for (int i = 0; i < n; ++i) {
        fixed_points_sum += power(m, __gcd(i, n));
    }

    // Calculate the number of different necklaces modulo 10^9+7
    long long result = (fixed_points_sum * power(n, MOD - 2)) % MOD;

    cout << result << endl;

    return 0;
}
