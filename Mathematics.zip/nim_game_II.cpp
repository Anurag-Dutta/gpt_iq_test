#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

unordered_map<int, bool> memo;

// Returns true if the current player wins from the current state
bool canWin(const vector<int>& heaps) {
    int state = 0;
    for (int heap : heaps) {
        state = state * 4 + heap;
    }

    if (memo.find(state) != memo.end()) {
        return memo[state];
    }

    for (std::vector<int>::size_type i = 0; i < heaps.size(); ++i) {
        for (int j = 1; j <= 3; ++j) {
            if (heaps[i] >= j) {
                vector<int> nextHeaps = heaps;
                nextHeaps[i] -= j;
                bool opponentWin = canWin(nextHeaps);
                if (!opponentWin) {
                    memo[state] = true;
                    return true;
                }
            }
        }
    }

    memo[state] = false;
    return false;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        vector<int> heaps(n);
        for (int i = 0; i < n; ++i) {
            cin >> heaps[i];
        }

        bool firstPlayerWins = canWin(heaps);
        if (firstPlayerWins) {
            cout << "first" << endl;
        } else {
            cout << "second" << endl;
        }

        memo.clear(); // Clear memoization for the next test case
    }

    return 0;
}
