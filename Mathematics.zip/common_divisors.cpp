#include <iostream>
#include <algorithm>
using namespace std;

int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int max_gcd(int arr[], int n) {
    int maxGCD = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            maxGCD = max(maxGCD, gcd(arr[i], arr[j]));
        }
    }
    return maxGCD;
}

int main() {
    int n;
    cin >> n;

    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }

    cout << max_gcd(arr, n) << endl;

    return 0;
}
