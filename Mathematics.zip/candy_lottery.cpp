#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int n, k;
    cin >> n >> k;

    double expected_maximum = (1.0 + k) / 2.0;

    cout << fixed << setprecision(6) << expected_maximum << endl;

    return 0;
}
