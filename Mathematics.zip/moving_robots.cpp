#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
    int k;
    cin >> k;

    double p = 1;
    double q = 1 - p / 4;
    
    double p_power_k = pow(p, k);
    double expected_empty_squares = 64 * p_power_k;

    cout << fixed << setprecision(6) << expected_empty_squares << endl;

    return 0;
}
