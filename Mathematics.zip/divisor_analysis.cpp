#include <iostream>
#include <cmath>
using namespace std;

const int MOD = 1e9 + 7;

long long mod_pow(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) {
            result = (result * base) % MOD;
        }
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

int main() {
    int n;
    cin >> n;

    long long number = 1, sum = 1, product = 1;
    for (int i = 0; i < n; ++i) {
        long long x, k;
        cin >> x >> k;

        // Calculate number of divisors
        number = (number * (k + 1)) % MOD;

        // Calculate sum of divisors
        sum = (sum * ((mod_pow(x, k + 1) - 1 + MOD) % MOD) * mod_pow(x - 1, MOD - 2)) % MOD;

        // Calculate product of divisors
        product = (product * (mod_pow(x, (k * (k + 1)) / 2))) % MOD;
    }

    cout << number << " " << sum << " " << product << endl;

    return 0;
}
