#include <iostream>
#include <vector>
using namespace std;

int calculateNimSum(const vector<int>& balls) {
    int nimSum = 0;
    for (int ball : balls) {
        nimSum ^= ball;
    }
    return nimSum;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        vector<int> balls(n);
        for (int i = 0; i < n; ++i) {
            cin >> balls[i];
        }

        int nimSum = calculateNimSum(balls);
        if (nimSum == 0) {
            cout << "second" << endl;
        } else {
            cout << "first" << endl;
        }
    }

    return 0;
}
